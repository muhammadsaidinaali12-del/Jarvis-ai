package com.example.speech

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface SpeechState {
    data object Idle : SpeechState
    data class Listening(val rmsDb: Float = 0f, val partialText: String = "") : SpeechState
    data object Processing : SpeechState
    data class Success(val spokenText: String) : SpeechState
    data class Error(val message: String, val isPermanent: Boolean = false, val isAudioHardwareIssue: Boolean = false) : SpeechState
}

class SpeechManager(private val context: Context) {
    private val tag = "JarvisSpeechManager"
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var sessionId = 0L

    private val _speechState = MutableStateFlow<SpeechState>(SpeechState.Idle)
    val speechState: StateFlow<SpeechState> = _speechState.asStateFlow()
    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    val isRecognitionAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    private fun isCurrent(id: Long): Boolean = id == sessionId

    private fun createListener(id: Long) = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (!isCurrent(id)) return
            _speechState.value = SpeechState.Listening()
            _rmsLevel.value = 0.1f
        }
        override fun onBeginningOfSpeech() {
            if (!isCurrent(id)) return
            _speechState.value = SpeechState.Listening(rmsDb = 0.3f)
        }
        override fun onRmsChanged(rmsdB: Float) {
            if (!isCurrent(id)) return
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _rmsLevel.value = normalized
            val current = _speechState.value
            if (current is SpeechState.Listening) _speechState.value = current.copy(rmsDb = normalized)
        }
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() {
            if (!isCurrent(id)) return
            _speechState.value = SpeechState.Processing
            _rmsLevel.value = 0f
        }
        override fun onError(error: Int) {
            if (!isCurrent(id)) return
            _rmsLevel.value = 0f
            val isAudioIssue = error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                    error == SpeechRecognizer.ERROR_AUDIO
            val message = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Tidak ada suara terdeteksi. Silakan coba lagi."
                SpeechRecognizer.ERROR_AUDIO -> "Gangguan input audio mikrofon. Periksa izin dan mikrofon perangkat."
                SpeechRecognizer.ERROR_CLIENT -> "Layanan pengenal suara belum siap atau terputus sementara. Silakan coba lagi."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Izin mikrofon (RECORD_AUDIO) belum diberikan."
                SpeechRecognizer.ERROR_NETWORK -> "Koneksi internet bermasalah untuk pengenal suara."
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Waktu koneksi jaringan pengenal suara habis."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Layanan suara sedang sibuk. Silakan coba lagi sebentar."
                SpeechRecognizer.ERROR_SERVER -> "Gangguan pada server pengenal suara."
                else -> "Gagal mengenali suara (Kode: $error)."
            }
            _speechState.value = SpeechState.Error(
                message = message,
                isPermanent = error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS,
                isAudioHardwareIssue = isAudioIssue
            )
            cleanupRecognizer(id)
        }
        override fun onResults(results: Bundle?) {
            if (!isCurrent(id)) return
            _rmsLevel.value = 0f
            val recognizedText = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim()
            _speechState.value = if (!recognizedText.isNullOrBlank()) {
                SpeechState.Success(recognizedText)
            } else {
                SpeechState.Error(
                    "Suara tidak terdengar jelas. Silakan ulangi.",
                    isAudioHardwareIssue = true
                )
            }
            cleanupRecognizer(id)
        }
        override fun onPartialResults(partialResults: Bundle?) {
            if (!isCurrent(id)) return
            val partialText = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim().orEmpty()
            if (partialText.isNotBlank()) {
                val current = _speechState.value
                if (current is SpeechState.Listening) _speechState.value = current.copy(partialText = partialText)
            }
        }
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    fun startListening() {
        mainHandler.post { attemptStartListening(0) }
    }

    private fun attemptStartListening(attempt: Int) {
        cleanupRecognizer()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _speechState.value = SpeechState.Error("Izin mikrofon (RECORD_AUDIO) belum diberikan.", isPermanent = true)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _speechState.value = SpeechState.Error(
                "Layanan pengenal suara tidak tersedia di perangkat ini.",
                isPermanent = true,
                isAudioHardwareIssue = true
            )
            return
        }
        if (!RecognizerOwnership.tryAcquire(RecognizerOwnership.Owner.COMMAND)) {
            if (attempt < 10) {
                mainHandler.postDelayed({ attemptStartListening(attempt + 1) }, 100L)
            } else {
                _speechState.value = SpeechState.Error("Mikrofon sedang digunakan oleh modul lain. Silakan coba lagi.", isAudioHardwareIssue = true)
            }
            return
        }

        val id = ++sessionId
        try {
            val appContext = context.applicationContext
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
                setRecognitionListener(createListener(id))
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            }
            _speechState.value = SpeechState.Listening()
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(tag, "Failed to start listening", e)
            _speechState.value = SpeechState.Error("Gagal memulai mikrofon: ${e.localizedMessage}", isAudioHardwareIssue = true)
            cleanupRecognizer(id)
        }
    }

    fun stopListening() {
        mainHandler.post {
            try { speechRecognizer?.stopListening() }
            catch (e: Exception) { Log.e(tag, "Error stopping recognizer", e) }
        }
    }

    fun cancel() {
        mainHandler.post {
            cleanupRecognizer()
            _rmsLevel.value = 0f
            _speechState.value = SpeechState.Idle
        }
    }

    fun resetState() {
        _speechState.value = SpeechState.Idle
        _rmsLevel.value = 0f
    }

    fun emitManualInput(text: String) {
        if (text.isNotBlank()) _speechState.value = SpeechState.Success(text.trim())
    }

    private fun cleanupRecognizer(expectedSession: Long? = null) {
        if (expectedSession != null && expectedSession != sessionId) return
        sessionId++
        val recognizer = speechRecognizer
        speechRecognizer = null
        try {
            recognizer?.setRecognitionListener(null)
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            Log.e(tag, "Error destroying speech recognizer", e)
        } finally {
            RecognizerOwnership.release(RecognizerOwnership.Owner.COMMAND)
        }
    }

    fun destroy() {
        mainHandler.post {
            cleanupRecognizer()
            mainHandler.removeCallbacksAndMessages(null)
        }
    }
}
