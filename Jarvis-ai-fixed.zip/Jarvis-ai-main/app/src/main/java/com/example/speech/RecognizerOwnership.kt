package com.example.speech

import android.util.Log

/**
 * Single process-wide owner for Android SpeechRecognizer instances.
 * It does not create recognizers; it only prevents WakeWordDetector and
 * SpeechManager from using the microphone at the same time.
 */
object RecognizerOwnership {
    enum class Owner { NONE, WAKE_WORD, COMMAND }

    private const val TAG = "RecognizerOwnership"
    private var owner: Owner = Owner.NONE

    @Synchronized
    fun tryAcquire(requester: Owner): Boolean {
        require(requester != Owner.NONE) { "NONE cannot acquire recognizer ownership" }
        if (owner == requester) return true
        if (owner != Owner.NONE) {
            Log.d(TAG, "Acquire denied: current=$owner requested=$requester")
            return false
        }
        owner = requester
        Log.d(TAG, "Ownership acquired: $requester")
        return true
    }

    @Synchronized
    fun release(requester: Owner) {
        if (owner != requester) return
        owner = Owner.NONE
        Log.d(TAG, "Ownership released: $requester")
    }

    @Synchronized
    fun forceRelease() {
        owner = Owner.NONE
    }

    @Synchronized
    fun currentOwner(): Owner = owner
}
