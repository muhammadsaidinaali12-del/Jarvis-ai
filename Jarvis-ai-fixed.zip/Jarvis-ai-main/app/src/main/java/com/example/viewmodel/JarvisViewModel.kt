package com.example.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.service.JarvisVoiceService
import com.example.speech.JarvisBrain
import com.example.speech.SpeechManager
import com.example.speech.SpeechState
import com.example.speech.TtsManager
import com.example.speech.WakeWordEvent
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class AssistantStatus { WAKE_WORD_LISTENING, ACTIVE_LISTENING, PROCESSING, SPEAKING, PAUSED, ERROR }

data class DialogueItem(
    val id: String = UUID.randomUUID().toString(),
    val userPrompt: String,
    val jarvisReply: String,
    val timestamp: String,
    val executedActionTitle: String? = null
)

data class JarvisUiState(
    val status: AssistantStatus = AssistantStatus.WAKE_WORD_LISTENING,
    val statusText: String = "JARVIS SIAGA // MENUNGGU WAKE WORD 'JARVIS'",
    val userSpokenText: String = "",
    val jarvisResponseText: String = "Halo Tuan, saya JARVIS V1. Panggil saya dengan mengucapkan \"JARVIS\" atau tekan tombol di bawah untuk memberikan perintah.",
    val history: List<DialogueItem> = emptyList(),
    val audioLevel: Float = 0f,
    val isTtsMuted: Boolean = false,
    val isPaused: Boolean = false,
    val errorMessage: String? = null,
    val isRecognitionAvailable: Boolean = true
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {
    private val speechManager = SpeechManager(application)
    private val ttsManager = TtsManager(application)
    private val jarvisBrain = JarvisBrain(application)

    private val _status = MutableStateFlow(AssistantStatus.WAKE_WORD_LISTENING)
    private val _userSpokenText = MutableStateFlow("")
    private val _jarvisResponseText = MutableStateFlow("Halo Tuan, saya JARVIS V1. Panggil saya dengan mengucapkan \"JARVIS\" atau tekan tombol di bawah untuk memberikan perintah.")
    private val _history = MutableStateFlow<List<DialogueItem>>(emptyList())
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _passiveAudioLevel = MutableStateFlow(0f)
    private var activeListeningTimeoutJob: Job? = null
    private var isProcessingCommand = false

    val isRecognitionAvailable: Boolean get() = speechManager.isRecognitionAvailable

    val uiState: StateFlow<JarvisUiState> = combine(
        _status,
        speechManager.rmsLevel,
        _passiveAudioLevel,
        ttsManager.isMuted,
        _userSpokenText,
        _jarvisResponseText,
        _history,
        _errorMessage
    ) { values ->
        val status = values[0] as AssistantStatus
        val activeRms = values[1] as Float
        val passiveRms = values[2] as Float
        val muted = values[3] as Boolean
        val spoken = values[4] as String
        val response = values[5] as String
        @Suppress("UNCHECKED_CAST") val history = values[6] as List<DialogueItem>
        val error = values[7] as String?

        val statusText = when (status) {
            AssistantStatus.WAKE_WORD_LISTENING -> "JARVIS SIAGA // MENUNGGU WAKE WORD 'JARVIS'"
            AssistantStatus.ACTIVE_LISTENING -> if (spoken.isNotBlank() && spoken != "Mendengarkan...") "JARVIS AKTIF: \"$spoken\"" else "JARVIS AKTIF // MENDENGARKAN PERINTAH ANDA..."
            AssistantStatus.PROCESSING -> "JARVIS MEMPROSES PERINTAH SUARA..."
            AssistantStatus.SPEAKING -> "JARVIS SEDANG MENJAWAB..."
            AssistantStatus.PAUSED -> "JARVIS DIJEDA // MIKROFON NONAKTIF"
            AssistantStatus.ERROR -> "STATUS: ${error ?: "ERROR"}"
        }
        val audio = when (status) {
            AssistantStatus.ACTIVE_LISTENING -> activeRms
            AssistantStatus.WAKE_WORD_LISTENING -> passiveRms
            AssistantStatus.SPEAKING -> 0.45f
            else -> 0f
        }
        JarvisUiState(
            status = status,
            statusText = statusText,
            userSpokenText = spoken,
            jarvisResponseText = response,
            history = history,
            audioLevel = audio,
            isTtsMuted = muted,
            isPaused = status == AssistantStatus.PAUSED,
            errorMessage = error,
            isRecognitionAvailable = isRecognitionAvailable
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), JarvisUiState())

    init {
        observeSpeechManager()
        observeWakeWordService()
        startBackgroundVoiceServiceIfPermitted()
    }

    private fun observeSpeechManager() {
        viewModelScope.launch {
            speechManager.speechState.collect { state ->
                when (state) {
                    SpeechState.Idle -> Unit
                    is SpeechState.Listening -> {
                        _errorMessage.value = null
                        _status.value = AssistantStatus.ACTIVE_LISTENING
                        if (state.partialText.isNotBlank()) _userSpokenText.value = state.partialText
                    }
                    SpeechState.Processing -> _status.value = AssistantStatus.PROCESSING
                    is SpeechState.Success -> processUserInput(state.spokenText)
                    is SpeechState.Error -> {
                        if (_status.value == AssistantStatus.PAUSED) return@collect
                        _errorMessage.value = state.message
                        _status.value = AssistantStatus.ERROR
                        speakWithWakeWordControl(
                            if (state.isAudioHardwareIssue) "Maaf Tuan, suara tidak terdengar jelas. Silakan coba lagi." else "Maaf Tuan, ${state.message}"
                        ) { returnToWakeWordListening() }
                    }
                }
            }
        }
    }

    private fun observeWakeWordService() {
        viewModelScope.launch {
            JarvisVoiceService.wakeWordEvents.collect { it?.let(::handleWakeWordEvent) }
        }
    }

    private fun handleWakeWordEvent(event: WakeWordEvent) {
        when (event) {
            is WakeWordEvent.Detected -> {
                _errorMessage.value = null
                vibratePhone()
                val inline = event.inlineCommand?.trim().orEmpty()
                if (inline.isNotBlank()) {
                    _userSpokenText.value = inline
                    processUserInput(inline)
                } else {
                    speakWithWakeWordControl("Ya, Tuan.") {
                        if (_status.value != AssistantStatus.PAUSED) startActiveCommandListening()
                    }
                }
            }
            is WakeWordEvent.AudioLevel -> if (_status.value == AssistantStatus.WAKE_WORD_LISTENING) _passiveAudioLevel.value = event.level
            is WakeWordEvent.Error -> if (!event.isRecoverable) {
                _errorMessage.value = event.message
                _status.value = AssistantStatus.ERROR
            }
            is WakeWordEvent.StatusChanged -> Unit
        }
    }

    private fun startActiveCommandListening() {
        if (_status.value == AssistantStatus.PAUSED) return
        JarvisVoiceService.muteDetectorForTts(getApplication())
        _status.value = AssistantStatus.ACTIVE_LISTENING
        _userSpokenText.value = "Mendengarkan..."
        _errorMessage.value = null
        speechManager.startListening()
        activeListeningTimeoutJob?.cancel()
        activeListeningTimeoutJob = viewModelScope.launch {
            delay(10000)
            if (_status.value == AssistantStatus.ACTIVE_LISTENING) {
                speechManager.stopListening()
                delay(300)
                returnToWakeWordListening()
            }
        }
    }

    private fun returnToWakeWordListening() {
        activeListeningTimeoutJob?.cancel()
        if (_status.value == AssistantStatus.PAUSED) return
        viewModelScope.launch {
            delay(500)
            if (_status.value == AssistantStatus.PAUSED) return@launch
            _status.value = AssistantStatus.WAKE_WORD_LISTENING
            _passiveAudioLevel.value = 0f
            _userSpokenText.value = ""
            JarvisVoiceService.unmuteDetectorAfterTts(getApplication())
        }
    }

    private fun speakWithWakeWordControl(text: String, onFinished: () -> Unit) {
        JarvisVoiceService.muteDetectorForTts(getApplication())
        _status.value = AssistantStatus.SPEAKING
        ttsManager.speak(text) {
            viewModelScope.launch {
                delay(250)
                if (_status.value != AssistantStatus.PAUSED) onFinished()
            }
        }
    }

    fun startBackgroundVoiceServiceIfPermitted() {
        val app = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            JarvisVoiceService.startService(app)
            if (_status.value != AssistantStatus.PAUSED) _status.value = AssistantStatus.WAKE_WORD_LISTENING
        } catch (e: Exception) {
            _errorMessage.value = "Gagal memulai service suara: ${e.localizedMessage ?: "kesalahan tidak diketahui"}"
            _status.value = AssistantStatus.ERROR
        }
    }

    fun onSpeakButtonPressed() {
        vibratePhone()
        when (_status.value) {
            AssistantStatus.ACTIVE_LISTENING -> speechManager.stopListening()
            AssistantStatus.SPEAKING -> { ttsManager.stop(); returnToWakeWordListening() }
            AssistantStatus.PAUSED -> resumeJarvis()
            else -> startActiveCommandListening()
        }
    }

    fun pauseJarvis() {
        vibratePhone()
        _status.value = AssistantStatus.PAUSED
        activeListeningTimeoutJob?.cancel()
        speechManager.cancel()
        ttsManager.stop()
        JarvisVoiceService.pauseService(getApplication())
    }

    fun resumeJarvis() {
        vibratePhone()
        _status.value = AssistantStatus.WAKE_WORD_LISTENING
        _errorMessage.value = null
        JarvisVoiceService.resumeService(getApplication())
    }

    fun togglePauseResume() { if (_status.value == AssistantStatus.PAUSED) resumeJarvis() else pauseJarvis() }

    fun cancelListening() {
        speechManager.cancel()
        returnToWakeWordListening()
    }

    fun processUserInput(input: String) {
        val command = input.trim()
        if (command.isBlank() || isProcessingCommand) return
        isProcessingCommand = true
        _userSpokenText.value = command
        _errorMessage.value = null
        _status.value = AssistantStatus.PROCESSING
        JarvisVoiceService.muteDetectorForTts(getApplication())
        viewModelScope.launch {
            try {
                val response = jarvisBrain.processCommand(command)
                _jarvisResponseText.value = response.displayText
                val timestamp = SimpleDateFormat("HH:mm", Locale.forLanguageTag("id-ID")).format(Date())
                _history.value = listOf(DialogueItem(userPrompt = command, jarvisReply = response.displayText, timestamp = timestamp, executedActionTitle = response.executedActionTitle)) + _history.value
                _status.value = AssistantStatus.SPEAKING
                ttsManager.speak(response.spokenText) { returnToWakeWordListening() }
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage ?: "Gagal memproses perintah."
                _status.value = AssistantStatus.ERROR
                speakWithWakeWordControl("Maaf Tuan, terjadi kesalahan saat memproses perintah.") { returnToWakeWordListening() }
            } finally {
                isProcessingCommand = false
            }
        }
    }

    fun replayAudio(text: String) {
        vibratePhone()
        speakWithWakeWordControl(text) { returnToWakeWordListening() }
    }

    fun toggleMute() { vibratePhone(); ttsManager.toggleMute() }
    fun clearHistory() { vibratePhone(); _history.value = emptyList() }
    fun stopSpeaking() { ttsManager.stop(); returnToWakeWordListening() }

    private fun vibratePhone() {
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION") val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
                else { @Suppress("DEPRECATION") val v = vibrator; v?.vibrate(35) }
            }
        } catch (_: Exception) { }
    }

    override fun onCleared() {
        activeListeningTimeoutJob?.cancel()
        speechManager.destroy()
        ttsManager.shutdown()
        try { JarvisVoiceService.stopService(getApplication()) } catch (_: Exception) { }
        super.onCleared()
    }
}
