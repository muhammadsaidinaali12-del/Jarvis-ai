package com.example.speech

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

sealed interface WakeWordEvent {
    data class Detected(val inlineCommand: String?) : WakeWordEvent
    data class AudioLevel(val level: Float) : WakeWordEvent
    data class StatusChanged(val isListening: Boolean) : WakeWordEvent
    data class Error(val message: String, val isRecoverable: Boolean = true) : WakeWordEvent
}

/** Passive JARVIS wake-word detector. Only one SpeechRecognizer may be active at a time. */
class WakeWordDetector(
    private val context: Context,
    var sensitivity: Float = DEFAULT_SENSITIVITY
) {
    companion object {
        private const val TAG = "JarvisWakeWord"
        const val WAKE_WORD = "JARVIS"
        const val DEFAULT_SENSITIVITY = 0.75f
        private val WAKE_WORD_PATTERNS = listOf(
            Regex("\b(jarvis|jar vis|djarvis|carvis|jarves|yarvis|jarviz|jar visual)\b", RegexOption.IGNORE_CASE),
            Regex("\b(hai|hei|halo|ok|oke)\s+(jarvis|jar vis|djarvis)\b", RegexOption.IGNORE_CASE)
        )
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var restartJob: kotlinx.coroutines.Job? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var sessionId = 0L
    private var isPassiveRunning = false
    private var isPaused = false
    private var listener: ((WakeWordEvent) -> Unit)? = null
    private var isMutedDuringTts = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private fun isCurrent(id: Long): Boolean = id == sessionId

    private fun createListener(id: Long) = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (!isCurrent(id)) return
            _isListening.value = true
            listener?.invoke(WakeWordEvent.StatusChanged(true))
        }
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) {
            if (!isCurrent(id)) return
            listener?.invoke(WakeWordEvent.AudioLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)))
        }
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onError(error: Int) {
            if (!isCurrent(id)) return
            cleanupRecognizer(id)
            if (!isPassiveRunning || isPaused || isMutedDuringTts) return
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                listener?.invoke(WakeWordEvent.Error("Izin mikrofon diperlukan untuk mendeteksi wake word.", false))
                return
            }
            val delayMs = when (error) {
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1000L
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 300L
                else -> 600L
            }
            restartPassiveListening(delayMs)
        }
        override fun onResults(results: Bundle?) {
            if (!isCurrent(id)) return
            val fullText = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            val detection = evaluateWakeWord(fullText)
            cleanupRecognizer(id)
            if (detection != null) {
                listener?.invoke(WakeWordEvent.Detected(detection.inlineCommand))
            } else if (isPassiveRunning && !isPaused && !isMutedDuringTts) {
                restartPassiveListening(200L)
            }
        }
        override fun onPartialResults(partialResults: Bundle?) {
            if (!isCurrent(id)) return
            val partialText = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            if (partialText.isBlank()) return
            val detection = evaluateWakeWord(partialText) ?: return
            cleanupRecognizer(id)
            listener?.invoke(WakeWordEvent.Detected(detection.inlineCommand))
        }
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    data class WakeWordMatch(val inlineCommand: String?)

    fun evaluateWakeWord(text: String): WakeWordMatch? {
        val lower = text.lowercase(Locale.forLanguageTag("id-ID")).trim()
        for (pattern in WAKE_WORD_PATTERNS) {
            val match = pattern.find(lower) ?: continue
            val afterWakeWord = lower.substring(match.range.last + 1).trim()
                .removePrefix(",").removePrefix(":").removePrefix("-").trim()
            return WakeWordMatch(if (afterWakeWord.length > 2) afterWakeWord else null)
        }
        return null
    }

    fun start(onEvent: (WakeWordEvent) -> Unit) {
        listener = onEvent
        isPassiveRunning = true
        isPaused = false
        restartJob?.cancel()
        scheduleStart(0L)
    }

    private fun scheduleStart(delayMs: Long) {
        restartJob?.cancel()
        restartJob = scope.launch {
            if (delayMs > 0) delay(delayMs)
            mainHandler.post {
                if (isPassiveRunning && !isPaused && !isMutedDuringTts) startInternal()
            }
        }
    }

    private fun startInternal() {
        if (!isPassiveRunning || isPaused || isMutedDuringTts) return
        cleanupRecognizer()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            listener?.invoke(WakeWordEvent.Error("Izin mikrofon belum diberikan.", false))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener?.invoke(WakeWordEvent.Error("Layanan Speech Recognition tidak tersedia.", false))
            return
        }
        if (!RecognizerOwnership.tryAcquire(RecognizerOwnership.Owner.WAKE_WORD)) {
            restartPassiveListening(150L)
            return
        }
        val id = ++sessionId
        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
                setRecognitionListener(createListener(id))
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            }
            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting passive wake-word listening", e)
            cleanupRecognizer(id)
            restartPassiveListening(1500L)
        }
    }

    private fun restartPassiveListening(delayMs: Long) {
        if (!isPassiveRunning || isPaused || isMutedDuringTts) return
        scheduleStart(delayMs)
    }

    fun muteForTts() {
        isMutedDuringTts = true
        restartJob?.cancel()
        mainHandler.post {
            cleanupRecognizer()
            _isListening.value = false
        }
    }

    fun unmuteAfterTts() {
        isMutedDuringTts = false
        if (isPassiveRunning && !isPaused) restartPassiveListening(500L)
    }

    fun pause() {
        isPaused = true
        restartJob?.cancel()
        mainHandler.post {
            cleanupRecognizer()
            _isListening.value = false
            listener?.invoke(WakeWordEvent.StatusChanged(false))
        }
    }

    fun resume() {
        isPaused = false
        if (isPassiveRunning) scheduleStart(100L)
    }

    fun stop() {
        isPassiveRunning = false
        isPaused = false
        restartJob?.cancel()
        mainHandler.post {
            cleanupRecognizer()
            _isListening.value = false
            listener?.invoke(WakeWordEvent.StatusChanged(false))
        }
    }

    fun destroy() {
        isPassiveRunning = false
        isPaused = true
        restartJob?.cancel()
        mainHandler.post {
            cleanupRecognizer()
            mainHandler.removeCallbacksAndMessages(null)
            listener = null
        }
        scope.cancel()
    }

    private fun cleanupRecognizer(expectedSession: Long? = null) {
        if (expectedSession != null && expectedSession != sessionId) return
        sessionId++
        val recognizer = speechRecognizer
        speechRecognizer = null
        try {
            recognizer?.setRecognitionListener(null)
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up passive recognizer", e)
        } finally {
            _isListening.value = false
            RecognizerOwnership.release(RecognizerOwnership.Owner.WAKE_WORD)
        }
    }
}
